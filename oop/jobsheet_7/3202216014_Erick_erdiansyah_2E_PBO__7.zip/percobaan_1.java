public class percobaan_1 {
  public static void main(String[] args) {
    String[] nama;
    nama = new String[5];
    nama[0] = "Andi";
    nama[1] = "Budi";
    nama[2] = "Cika";
    nama[3] = "Dika";
    nama[4] = "Edo";
    System.out.println("Nama 1: " + nama[0]);
    System.out.println("Nama 2: " + nama[1]);
    System.out.println("Nama 3: " + nama[2]);
    System.out.println("Nama 4: " + nama[3]);
    System.out.println("Nama 5: " + nama[4]);

    System.out.println();
    System.out.println("Setelah Perubahan");
    System.out.println();
    nama[0] = "Andika";
    nama[1] = "Budiman";
    nama[2] = "Chika";
    nama[3] = "Dhika";
    nama[4] = "Edho";
    System.out.println("Nama 1: " + nama[0]);
    System.out.println("Nama 2: " + nama[1]);
    System.out.println("Nama 3: " + nama[2]);
    System.out.println("Nama 4: " + nama[3]);
    System.out.println("Nama 5: " + nama[4]);
    }
}
